<?php

include 'Views/html_top.html';
include 'Views/registration_page.php';

?>

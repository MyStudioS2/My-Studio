<?php

include 'Controllers/destroy_session_informations.php';
include 'Views/html_top.html';
include 'Views/login_page.php';

?>

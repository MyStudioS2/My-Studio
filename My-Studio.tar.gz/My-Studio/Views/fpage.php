    <link rel="stylesheet" type="text/css" href="Views/CSS/login_registration.css">
</head>
<body>
<!--Barre horizontale-->
<ul class="hori">
<li class="hori">
<a class="hori active" href="">MyStudio</a>
</li>
<li class="hori">
<img src='Views/images/LOGO.jpg'width='100' height='90'>
</li>
<li style="float:right">
<a class="hori1" href="">MyStudio, C'est quoi ?<!--Image--></a>
</li>
</ul>
<script src="Views/jquery.js"></script>
<script src="Views/style.js"></script>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>
<form action="" method="GET">
<button name="page" value="register">S'inscrire</button>
<button name="page" value="login">Se connecter</button>
</form>
</center>

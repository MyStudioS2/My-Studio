<div class='barre'>
<!--Barre horizontale-->
<ul class="horizontale">
<li class="horizontale">
<a class="horizontale active" href="">MyStudio</a>
</li>
<li class="horizontale">
<img class='img' src='Views/images/LOGO.jpg'width='100' height='90'>
</li>
<li style="float:right">
<!--<a class="horizontale1" href=""><!--Image--></a>-->
</li>
</ul>
</div>

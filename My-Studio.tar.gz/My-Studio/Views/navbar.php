<div id="navbar" class="container">
    <ul id="menu" class="menu1">
        <li id="liste_menu" class="form"><div class="container"><form action="" method="POST"><input type="text" id = "search_form" name"search" value ="" placeholder="Chercher une musique...">
	    <input type="image" id = "icon" src="Views/images/search_icon.svg" name="valider" value="">
	     </form></div></li>
        <li id="liste_menu" class = "liste"><a href="index.php?page=accueil_membres" id = "ahref" class ="acc">Accueil</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=parcourir" id = "ahref" class ="acc">Parcourir</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=nouveautes" id = "ahref" class ="acc">Nouveautés</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=favorites" id = "ahref" class ="acc">Coups de coeur</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=playlists" id = "ahref" class ="acc">Playlists</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=settings" id = "ahref" class ="acc">Paramètres</a></li><hr>
        <li id="liste_menu" class = "liste"><a href="index.php?page=logout" id = "ahref" class ="acc">Déconnexion</a></li><hr>
    </ul>
</div>
